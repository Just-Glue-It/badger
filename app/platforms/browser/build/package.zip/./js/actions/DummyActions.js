import {DUMMY_INCREMENT_ACTION} from './../constants/action-constants';

export function increment() {
  return {
    type: DUMMY_INCREMENT_ACTION,
  };
}
