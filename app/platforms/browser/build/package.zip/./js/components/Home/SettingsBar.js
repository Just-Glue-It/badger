import React, {PropTypes} from 'react';

const LeftNav = require('material-ui/lib/left-nav');
