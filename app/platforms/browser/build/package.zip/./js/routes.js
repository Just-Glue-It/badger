import Register from './components/Register';
import Login from './components/Login';
import Home from './components/Home';

console.log('print register', Register);
export default {
  LOGIN: Login,
  REGISTER: Register,
  HOME: Home
};
