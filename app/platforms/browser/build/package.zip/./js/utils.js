const ENTER_KEY = 13;
const ESC_KEY = 27;

export {ENTER_KEY, ESC_KEY};
