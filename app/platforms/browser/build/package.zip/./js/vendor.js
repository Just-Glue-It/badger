// TODO: figure out if we need this
module.exports = [
  '@cycle/core',
  '@cycle/dom'
];
